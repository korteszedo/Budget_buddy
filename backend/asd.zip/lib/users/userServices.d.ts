export declare function loginUser(email: string, password: string): Promise<any>;

import app from "./app";

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`A szerver fut a ${PORT}-es porton`);
});




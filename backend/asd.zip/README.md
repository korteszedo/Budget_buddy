
# Typescript module
